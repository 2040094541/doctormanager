create
    definer = root@localhost procedure cqtest(IN moneys decimal(10, 2), IN card_nums varchar(50), IN lx varchar(50))
BEGIN
   DECLARE nums DECIMAL(10,2) DEFAULT 0;
   DECLARE num DECIMAL(10,2) DEFAULT 0;
   SELECT card_id INTO num FROM card_info WHERE card_num=card_nums;
   SET autocommit=0;
   IF lx='存入' THEN
     SELECT balance INTO nums FROM card_info WHERE card_num=card_nums;
     SET nums=nums+moneys;
     UPDATE card_info SET balance=balance+moneys WHERE card_num=card_nums;
     INSERT INTO trade_info(card_id,card_num,trade_num,trade_type) VALUES 
     (num,card_nums,moneys,1);
      IF nums<0 THEN
        ROLLBACK;
        SELECT '存款失败，事务已回滚' AS STATUS;
      ELSE  
        COMMIT;
        SELECT '存款成功' AS STATUS;
     END IF;      
   ELSE
     SELECT balance INTO nums FROM card_info WHERE card_num=card_nums;
     SET nums=nums-moneys;
     UPDATE card_info SET balance=balance-moneys WHERE card_num=card_nums;
     INSERT INTO trade_info(card_id,card_num,trade_num,trade_type) VALUES 
     (num,card_nums,moneys,2);
      IF nums<0 THEN
        ROLLBACK;
        SELECT '取款失败，事务已回滚' AS STATUS;
      ELSE 
        COMMIT;
        SELECT '取款成功' AS STATUS;
      END IF;  
   END IF;
   SET autocommit=1;
END;

