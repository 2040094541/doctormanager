create
    definer = root@localhost procedure f()
BEGIN
	DECLARE s_amount1 DECIMAL(10,2);
	DECLARE s_amount2 DECIMAL(10,2);
	SELECT SUM(trade_num) INTO s_amount1 FROM trade_info WHERE trade_type=2;
	SELECT SUM(trade_num) INTO s_amount2 FROM trade_info WHERE trade_type=1;
	
	CREATE TABLE IF NOT EXISTS ni(
	TYPE VARCHAR(255),
	amount DECIMAL(10,2)
	);
	INSERT INTO ni VALUES('支取',s_amount1),('存入',s_amount2);
	SELECT * FROM ni;
	DROP TABLE ni;
END;

