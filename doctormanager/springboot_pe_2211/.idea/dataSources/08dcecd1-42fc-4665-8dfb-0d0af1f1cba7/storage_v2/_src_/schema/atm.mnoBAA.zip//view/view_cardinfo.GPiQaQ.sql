create view view_cardinfo as
select `atm`.`card_info`.`card_id`      AS `card_id`,
       `atm`.`card_info`.`user_id`      AS `user_id`,
       `atm`.`card_info`.`card_num`     AS `card_num`,
       `atm`.`card_info`.`opening_date` AS `opening_date`,
       `atm`.`card_info`.`balance`      AS `balance`,
       `atm`.`card_info`.`is_loss`      AS `is_loss`
from `atm`.`card_info`
where (`atm`.`card_info`.`is_loss` = 2);

-- comment on column view_cardinfo.is_loss not supported: 1:是,2:否

