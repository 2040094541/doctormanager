create view view_tradeinfo as
select `atm`.`trade_info`.`trade_id`   AS `trade_id`,
       `atm`.`trade_info`.`card_id`    AS `card_id`,
       `atm`.`trade_info`.`service_id` AS `service_id`,
       `atm`.`trade_info`.`card_num`   AS `card_num`,
       `atm`.`trade_info`.`trade_date` AS `trade_date`,
       `atm`.`trade_info`.`trade_num`  AS `trade_num`,
       `atm`.`trade_info`.`trade_type` AS `trade_type`,
       `atm`.`trade_info`.`ps`         AS `ps`
from `atm`.`trade_info`;

-- comment on column view_tradeinfo.trade_type not supported: 1:存入,2:支取

-- comment on column view_tradeinfo.ps not supported: 备注说明

