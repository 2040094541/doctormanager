create
    definer = root@localhost function fn() returns int
    return 100;

