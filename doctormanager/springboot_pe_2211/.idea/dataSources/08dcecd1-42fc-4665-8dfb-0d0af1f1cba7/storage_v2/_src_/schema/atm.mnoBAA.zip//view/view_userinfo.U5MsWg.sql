create view view_userinfo as
select `atm`.`user_info`.`user_id` AS `user_id`,
       `atm`.`user_info`.`NAME`    AS `NAME`,
       `atm`.`user_info`.`phone`   AS `phone`,
       `atm`.`user_info`.`address` AS `address`
from `atm`.`user_info`;

