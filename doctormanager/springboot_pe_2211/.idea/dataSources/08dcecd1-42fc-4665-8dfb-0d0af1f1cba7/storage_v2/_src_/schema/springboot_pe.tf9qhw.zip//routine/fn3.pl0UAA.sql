create
    definer = root@localhost function fn3() returns int
    return 100;

