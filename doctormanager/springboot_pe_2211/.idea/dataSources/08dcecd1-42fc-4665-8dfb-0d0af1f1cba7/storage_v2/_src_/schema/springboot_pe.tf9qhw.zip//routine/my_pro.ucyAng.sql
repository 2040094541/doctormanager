create
    definer = root@localhost procedure my_pro(INOUT n int)
begin
set n:=n+10;
end;

